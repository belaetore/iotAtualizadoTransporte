import HeroSection from "@/components/HeroSection";
import AdvantagesSection from "@/components/AdvantagesSection";
import ChallengesSection from "@/components/ChallengesSection";
import ExpectationsSection from "@/components/ExpectationsSection";
import ExamplesSection from "@/components/ExamplesSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="w-full">
      <HeroSection />
      <AdvantagesSection />
      <ChallengesSection />
      <ExpectationsSection />
      <ExamplesSection />
      <Footer />
    </div>
  );
};

export default Index;
