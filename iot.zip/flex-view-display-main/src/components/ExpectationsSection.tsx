const ExpectationsSection = () => {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <img 
        src="/lovable-uploads/5f477ed5-7d5c-4e62-92bb-375815587059.png"
        alt="Expectativas do IoT em Transportes"
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default ExpectationsSection;