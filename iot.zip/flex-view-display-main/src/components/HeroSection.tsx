const HeroSection = () => {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <img 
        src="/lovable-uploads/8837cfeb-3ca6-42d4-9737-e410527784f1.png"
        alt="Transportes na Internet das Coisas"
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default HeroSection;