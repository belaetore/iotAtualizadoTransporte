const Footer = () => {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <img 
        src="/lovable-uploads/eb26cceb-822e-4714-b4c3-1c93e9999579.png"
        alt="Footer SENAI"
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default Footer;