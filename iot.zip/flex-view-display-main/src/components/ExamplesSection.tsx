const ExamplesSection = () => {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <img 
        src="/lovable-uploads/9c46fb9d-f991-4b57-90ac-25039b4ff2f8.png"
        alt="Exemplos de IoT em Transportes"
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default ExamplesSection;