const AdvantagesSection = () => {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <img 
        src="/lovable-uploads/39116839-3cd5-461d-acb1-09286bcb7e0e.png"
        alt="Vantagens do IoT em Transportes"
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default AdvantagesSection;