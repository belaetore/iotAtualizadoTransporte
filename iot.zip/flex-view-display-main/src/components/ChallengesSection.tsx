const ChallengesSection = () => {
  return (
    <div className="w-full h-screen flex items-center justify-center">
      <img 
        src="/lovable-uploads/2118720a-9f3a-4afd-ac0a-471b5dd5861c.png"
        alt="Desafios do IoT em Transportes"
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default ChallengesSection;